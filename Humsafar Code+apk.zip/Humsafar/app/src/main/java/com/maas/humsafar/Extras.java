package com.maas.humsafar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Extras extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extras);
        Button firstAid=findViewById(R.id.buttonFirstAid);
        firstAid.setText(getResources().getString(R.string.firstaid));
        Button selfDefence=findViewById(R.id.buttonSelfDefence);
        selfDefence.setText(getResources().getString(R.string.selfdefence));
        firstAid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Extras.this,FirstAid.class));
            }
        });
        selfDefence.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Extras.this,SelfDefence.class));

            }
        });
    }
    public void loadNext(View v){
        Intent intent = new Intent(Extras.this, webDisplay.class);
        switch(v.getId()){
            case R.id.imageView4:
                intent.putExtra("url","https://www.allrecipes.com/recipes/1642/everyday-cooking/");
                break;
            case R.id.imageView7:
                intent.putExtra("url","https://www.pdfdrive.com/");
                break;
            case R.id.imageView8:
                intent.putExtra("url","https://www.biba.in/");
                break;
            case R.id.imageView9:
                intent.putExtra("url","https://tourism.gov.in/");
                break;
        }
        startActivity(intent);
    }

}
