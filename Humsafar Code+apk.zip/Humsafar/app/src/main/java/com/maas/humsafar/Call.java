package com.maas.humsafar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.security.auth.login.LoginException;

public class Call extends AppCompatActivity {
    Location location1;
    FusedLocationProviderClient fusedLocationProvider;
    ArrayList<String> pinCodeArray = new ArrayList<>();
    ArrayList<String> phoneNumberArray = new ArrayList<>();
    ArrayList<String> latitudesArray = new ArrayList<>();
    ArrayList<String> longitudesArray = new ArrayList<>();
    ArrayList<Float> distancesArray = new ArrayList<>();
    DatabaseHelper databaseHelper;
    SmsManager smsManager;
    Cursor cursor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);
        boolean unlock=false;
        fusedLocationProvider = LocationServices.getFusedLocationProviderClient(this);
        databaseHelper = new DatabaseHelper(this);
        smsManager = SmsManager.getDefault();
        cursor = databaseHelper.getAllData();
        while (cursor.moveToNext()) {
            pinCodeArray.add(cursor.getString(3));
            phoneNumberArray.add(cursor.getString(2));

        }
        if(phoneNumberArray.size()>0) {
            requestPermissions();
            convertPinToLatLong();


            getLocation();
            finishAndRemoveTask();
        }
        else{
            Toast.makeText(Call.this, "Add contacts", Toast.LENGTH_LONG).show();
        }
        //goBack();
    }

    public void convertPinToLatLong() {
        Geocoder geocoder = new Geocoder(this);
        try {
            for (int i = 0; i < pinCodeArray.size(); i++) {
                List<Address> addresses = geocoder.getFromLocationName(pinCodeArray.get(i), 1);
                Address address = addresses.get(0);
                latitudesArray.add(Double.toString(address.getLatitude()));
                longitudesArray.add(Double.toString(address.getLongitude()));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getLocation() {
        fusedLocationProvider.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {

                        // Got last known location. In some rare situations this can be null.
                        if (location != null) {
                            location1 = new Location("User");
                            Location location2 = new Location("Contact");
                            location1.setLatitude(location.getLatitude());
                            location1.setLongitude(location.getLongitude());
                            for (int i = 0; i < latitudesArray.size(); i++) {
                                location2.setLongitude(Double.parseDouble(longitudesArray.get(i)));
                                location2.setLatitude(Double.parseDouble(latitudesArray.get(i)));
                                distancesArray.add(location1.distanceTo(location2));
                            }
                            int min = distancesArray.indexOf(Collections.min(distancesArray));
                            Cursor cursor = databaseHelper.getCallingNumber(pinCodeArray.get(min));
                cursor.moveToNext();
                if (cursor.getCount() == 0) {
                    Toast.makeText(Call.this, "Invalid Pin", Toast.LENGTH_SHORT).show();
                } else {
                    String number = cursor.getString(2);
                    Log.i("NUMBER: ", number);
                    if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    Activity#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for Activity#requestPermissions for more details.
                        return;
                    }
                    sendMessageToAll();

                    startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number)));
                }
                            // Logic to handle location object
                        }
                        else{Toast.makeText(Call.this, "Not Successful", Toast.LENGTH_SHORT).show();}

                    }
                });


    }
    public void sendMessageToAll(){
        cursor=databaseHelper.getAllData();
        while (cursor.moveToNext()){
        smsManager.sendTextMessage(cursor.getString(2), null, "EMERGENCY !!! I need help. I am here Latitude,Longitude\n "+"https://www.google.com/maps/place/"+location1.getLatitude()+","+location1.getLongitude(),null, null);

        }
    }
    private void requestPermissions(){
        ArrayList<String> permissions = new ArrayList<String>();

        if(ContextCompat.checkSelfPermission(Call.this,
                Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED){
            permissions.add(Manifest.permission.SEND_SMS);
        }

        if(ContextCompat.checkSelfPermission(Call.this,
                Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if(ContextCompat.checkSelfPermission(Call.this,
                Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
            permissions.add(Manifest.permission.CALL_PHONE);
        }
        if(permissions.size()>0) {
            String[] per = new String[permissions.size()];
            per = permissions.toArray(per);
            ActivityCompat.requestPermissions(Call.this, per, 1);
        }

    }

}

