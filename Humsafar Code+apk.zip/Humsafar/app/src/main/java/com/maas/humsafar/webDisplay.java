package com.maas.humsafar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;

public class webDisplay extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_display);
        Intent intent = getIntent();
        String url = intent.getStringExtra("url");
        WebView webView=findViewById(R.id.webView);
        webView.loadUrl(url);
    }
}
