package com.maas.humsafar;

import android.content.Intent;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.telephony.SmsManager;
import android.widget.Toast;

public class Emergency extends TileService {

    public final Tile tile = getQsTile();

    @Override
    public void onClick() {
        super.onClick();
        //tile.setState(Tile.STATE_ACTIVE);
        Intent intent = new Intent(getApplicationContext(),Call.class);
         intent.setFlags(intent.FLAG_ACTIVITY_NEW_TASK);

        startActivityAndCollapse(intent);
        //Toast.makeText(this, "Clicked", Toast.LENGTH_SHORT).show();
    }

    public void onTileAdded() {
        super.onTileAdded();
        // Update state
        tile.setState(Tile.STATE_INACTIVE);
        // Update looks
        tile.updateTile();

    }
}
