package com.maas.humsafar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;

import java.util.Locale;

import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class AppSettings extends AppCompatActivity {
    Button englishButton, hindiButton;

    public static final String FILE_NAME = "file_lang"; // preference file name
    public static final String KEY_LANG = "key_lang";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadLanguage();
        setContentView(R.layout.activity_app_settings);
        englishButton = findViewById(R.id.buttonEnglish);
        hindiButton = findViewById(R.id.buttonHindi);
        hindiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveLanguage("hi");
                Toast.makeText(AppSettings.this, "Restart app to see changes", Toast.LENGTH_SHORT).show();
            }
        });
        englishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                saveLanguage("en");
                Toast.makeText(AppSettings.this, "Restart app to see changes", Toast.LENGTH_SHORT).show();

            }
        });
    }
    private void loadLanguage() {
        // we can use this method to load language,
        // this method should be called before setContentView() method of the onCreate method
        Locale locale = new Locale(getLangCode());
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }

    private String getLangCode() {
        SharedPreferences preferences = getSharedPreferences(FILE_NAME, MODE_PRIVATE);
        String langCode = preferences.getString(KEY_LANG, "en");
        // save english 'en' as the default language
        return langCode;
    }
    private void saveLanguage(String lang) {
        // we can use this method to save language
        SharedPreferences preferences = getSharedPreferences(FILE_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(KEY_LANG, lang);
        editor.apply();
        // we have saved
        // recreate activity after saving to load the new language, this is the same
        // as refreshing activity to load new language
        recreate();
    }
}