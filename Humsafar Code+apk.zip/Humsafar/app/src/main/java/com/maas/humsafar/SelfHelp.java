package com.maas.humsafar;

import androidx.appcompat.app.AppCompatActivity;

public class SelfHelp extends AppCompatActivity {
}
