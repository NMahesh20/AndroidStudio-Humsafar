package com.maas.humsafar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddContacts extends AppCompatActivity {
    Boolean verifName=false;
    Boolean verifPhone=false;
    Boolean verifPin=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contacts);
        final EditText phoneNumberEdit, pinCodeEdit, nameEdit;
        phoneNumberEdit = findViewById(R.id.editTextPhone);
        pinCodeEdit = findViewById(R.id.editTextPin);
        nameEdit = findViewById(R.id.editTextName);
        Button addContact = findViewById(R.id.buttonAddContact);

        final DatabaseHelper databaseHelper = new DatabaseHelper(this);
        addContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phone = phoneNumberEdit.getText().toString();
                String name = nameEdit.getText().toString();
                String pinCode = pinCodeEdit.getText().toString();



                if(name.equals(""))
                    Toast.makeText(AddContacts.this, "Name Cannot be empty", Toast.LENGTH_LONG).show();
                else verifName=true;
                if(phone.length()!=10)
                    Toast.makeText(AddContacts.this, "Phone Number cannot be empty", Toast.LENGTH_LONG).show();
                else
                    verifPhone=true;
                if(pinCode.length()!=6)
                    Toast.makeText(AddContacts.this, "Invalid Pin code", Toast.LENGTH_SHORT).show();
                else
                    verifPin=true;
                if(verifName&& verifPin && verifPhone){
                databaseHelper.insertValues(name,phone,pinCode);

                Toast.makeText(AddContacts.this, "Contact Added", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(AddContacts.this,MainActivity.class);
                startActivity(intent);}
            }
        });
    }
}
