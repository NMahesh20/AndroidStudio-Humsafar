package com.maas.humsafar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class PlaySound extends AppCompatActivity {
    MediaPlayer mediaPlayer;
    Boolean buttonClick;
    Button buttonStop;
    private String mCameraId;
    private CameraManager mCameraManager;
    String sos="...---...";
    int i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_play_sound);

        AudioManager mgr = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
        int valuess = 15;//range(0-15)
       mgr.setStreamVolume(AudioManager.STREAM_MUSIC, valuess, 0);
        mCameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            i=0;
        try {
            mCameraId = mCameraManager.getCameraIdList()[0];
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(this, R.raw.audio);

        }
        buttonStop = findViewById(R.id.buttonStop);
        //requestPermissions();
        buttonClick = false;
        buttonStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonClick=true;
            }
        });

        CountDownTimer cntr_aCounter = new CountDownTimer(300000, 1000) {
            public void onTick(long millisUntilFinished) {
                if (!buttonClick) {
                    mediaPlayer.start();
                    try {
                        if(i%9 == 0){
                            Thread.sleep(2100);
                        }
                        if (sos.charAt(i % 9) == '.') {
                            flash(true);
                            Thread.sleep(300);
                            flash(false);
                            Thread.sleep(150);


                        } else {
                            flash(true);
                            Thread.sleep(900);
                            flash(false);
                            Thread.sleep(150);
                        }
                        i++;
                    }
                    catch (Exception e){
                        //
                    }

                }else{
                    flash(false);
                    mediaPlayer.stop();
                    //mediaPlayer=null;
                    finishAndRemoveTask();
                    //goBack();
                }
            }



                public void onFinish () {
                    //code fire after finish
                    flash(false);
                    mediaPlayer.stop();
                }

        };cntr_aCounter.start();



    }
public void flash(boolean status){
    try {
        mCameraManager.setTorchMode(mCameraId, status);
    } catch (CameraAccessException e) {
        e.printStackTrace();
    }
}
    public void goBack(){
        Intent i = new Intent (PlaySound.this,MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); // Adds the FLAG_ACTIVITY_NO_HISTORY flag
        //i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        //i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        finishAffinity();
        startActivity(i);

}
    private void requestPermissions(){
        ArrayList<String> permissions = new ArrayList<String>();

        if(ContextCompat.checkSelfPermission(PlaySound.this,
                Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED){
            permissions.add(Manifest.permission.CAMERA);
        }

        if(permissions.size()>0) {
            String[] per = new String[permissions.size()];
            per = permissions.toArray(per);
            ActivityCompat.requestPermissions(PlaySound.this, per, 1);
        }

    }
}
