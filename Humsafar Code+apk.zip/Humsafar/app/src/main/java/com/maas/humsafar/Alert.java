package com.maas.humsafar;

import android.content.Intent;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.widget.Toast;

public class Alert extends TileService {
    public final Tile tile =getQsTile();
    private CameraManager mCameraManager;
    @Override
    public void onClick() {
        super.onClick();
        //tile.setState(Tile.STATE_ACTIVE);
        Intent intent = new Intent(getApplicationContext(),PlaySound.class);
        intent.setFlags(intent.FLAG_ACTIVITY_NEW_TASK);
        startActivityAndCollapse(intent);
        Toast.makeText(this, "Ringing", Toast.LENGTH_SHORT).show();
    }
    public void onTileAdded() {
        super.onTileAdded();
        // Update state
        tile.setState(Tile.STATE_INACTIVE);
        // Update looks
        tile.updateTile();

    }
}
