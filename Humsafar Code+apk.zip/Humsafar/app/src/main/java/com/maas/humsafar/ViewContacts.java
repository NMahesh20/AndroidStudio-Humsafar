package com.maas.humsafar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class ViewContacts extends AppCompatActivity {
    private ArrayList<ExampleItem> mExampleList;
    private RecyclerView mRecyclerView;
    private ExampleAdapter mAdapter;
    DatabaseHelper mDatabaseHelper;
    FloatingActionButton floatingActionButton;
    Cursor data;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_contacts);

        mDatabaseHelper = new DatabaseHelper(this);
        floatingActionButton=findViewById(R.id.floatingActionButton2);
        createExampleList();
        buildRecycleView();
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ViewContacts.this,AddContacts.class));
            }
        });
    }

    public void removeItem(int position) {
        mExampleList.remove(position);
        mAdapter.notifyItemRemoved(position);
    }

    public void createExampleList() {
        mExampleList = new ArrayList<>();
        data = mDatabaseHelper.getAllData();
        int img;
        while (data.moveToNext()) {
            img = R.drawable.ic_user2;
            mExampleList.add(new ExampleItem(img, data.getString(1), getResources().getString(R.string.phone_number) +": " + data.getString(2) + "\n"+getResources().getString(R.string.pin_code)+":" + data.getString(3)));
        }

    }

    public void buildRecycleView() {
        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ExampleAdapter(mExampleList);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.setOnItemClickListener(new ExampleAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                mExampleList.get(position);

            }

            /*
                        @Override
                        public void onDoneClick(int position) {
                            data.moveToPosition(position);
                            mDatabaseHelper.updateData(data.getString(0),data.getString(1),data.getString(2));
                            Toast.makeText(HomeActivity.this,"Finished "+data.getString(0),Toast.LENGTH_SHORT).show();
                            mAdapter.notifyDataSetChanged();
                            mExampleList.get(position).changeImg(R.drawable.ic_done);
                            data =mDatabaseHelper.getData();

                        }
            */
            @Override
            public void onDeleteClick(int position) {
                data.moveToPosition(position);
                Toast.makeText(ViewContacts.this, "Deleted Contact of " + data.getString(1), Toast.LENGTH_SHORT).show();
                mDatabaseHelper.deleteData(data.getString(1), data.getString(2), data.getString(3));
                removeItem(position);
                data = mDatabaseHelper.getAllData();

            }

            @Override
            public void onCallClick(int position) {
                data.moveToPosition(position);
                if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    Activity#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for Activity#requestPermissions for more details.
                    return;
                }
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + data.getString(2))));

            }
        });

    }
}
